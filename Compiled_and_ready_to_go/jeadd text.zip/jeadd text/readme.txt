how to use:

drag smol image into the exe file.
wait a bit till the console shows End.
Press Enter

BOOOM!

now you have two files:
out.png - how the image should look like.
out.pygrrmodel - the actual file ya can load in the PolyArt Thingy.



Copyright by me lol