﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using System.Drawing;

namespace JEAFF_PIXEL_ART_THING
{
    class Program
    {
        static List<string> data;
        static List<(float x, float y)> points;
        static void AddPoint(float x, float y)
        {
            points.Add((x,y));
            data.Add($"\n        [\n            {String.Format(CultureInfo.InvariantCulture, "{0:n}", x)},\n            {String.Format(CultureInfo.InvariantCulture, "{0:n}", y)}\n        ],");
        }


        static void End()
        {
            Console.WriteLine("\nEnd.");
            Console.ReadLine();
        }


        static void AddSquare(float x, float y, float size_x, float size_y)
        {
            AddPoint(x, y);
            AddPoint(x + size_x, y);
            AddPoint(x + size_x, y + size_y);
            AddPoint(x, y + size_y);
            AddPoint(x, y);

            AddPoint(0, 0);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Masl Image to Pygrr PolyArt Thingy Converter v1.4 - Made by Masldasl (Marceldobehere)");
            Console.WriteLine("-------------------------------------------------");

            System.Threading.Thread.Sleep(500);

            Console.Clear();

            if (args.Length > 0)
            {
                if (File.Exists(args[0]))
                {
                    string start_1;
                    string start_2;
                    string end;
                    try
                    {
                        start_1 = new StreamReader("core/start_1.txt").ReadToEnd();
                        start_2 = new StreamReader("core/start_2.txt").ReadToEnd();
                        end = new StreamReader("core/end.txt").ReadToEnd();
                    }
                    catch
                    {
                        Console.WriteLine("ERROR: Core Files not found!");
                        End();
                        return;
                    }



                    points = new List<(float x, float y)>();
                    data = new List<string>();
                    AddPoint(0, 0);

                    Bitmap temp = new Bitmap(args[0]);

                    (int x, int y) size = (temp.Size.Width, temp.Size.Height);

                    //AddSquare(0, 0, 1, 1);

                    //AddSquare(-18, 14);
                    //AddSquare(-18, -15);
                    //AddSquare(16, 14);
                   // AddSquare(16, -15);

                    // Screen goes from X -18 to 16 (35 pixels)
                    //                  Y -15 to 14 (30 pixels)

                    // Screen res is 35x30px





                    float pixelsize = Math.Max((size.x / 35f), (size.y / 30f));

                    for (int y = 0; y < size.y; y++)
                    {
                        int x = 0;
                        while (x < size.x)
                        {
                            int temp_size = 0;
                            while (temp.GetPixel(x, y).GetBrightness() < 0.5f)
                            {
                                temp.SetPixel(x, y, Color.Black);
                                temp_size++;
                                x++;
                                if (x >= size.x)
                                {
                                    break;
                                }
                            }
                            if (temp_size > 0)
                            {
                                AddSquare(((((x - temp_size) / pixelsize)) - 18), (((((size.y - 1) - y) / pixelsize)) - 15), (temp_size / pixelsize), (1 / pixelsize));
                            }
                            else
                            {
                                temp.SetPixel(x, y, Color.White);
                                x++;
                            }
                        }
                    }




                    List<string> output = new List<string>();
                    output.Add(start_1);
                    output.AddRange(data);
                    output[output.Count - 1] = output.Last().Substring(0, output.Last().Length - 1);
                    output.Add("\n" + start_2);
                    output.AddRange(data);
                    output[output.Count - 1] = output.Last().Substring(0, output.Last().Length - 1);
                    output.Add("\n" + end);





                    Console.WriteLine("\nOutput:");
                    StreamWriter writer = new StreamWriter("out.pygrrmodel");
                    foreach (string y in output)
                    {
                        Console.Write(y);
                        writer.Write(y);
                    }
                    writer.Close();


                    temp.Save("out.png");
                }
                else
                {
                    Console.WriteLine("ERROR: Image doesn't exist...");
                }
            }
            else
            {
                Console.WriteLine("ERROR: No Image opened with...");
            }

            End();
            return;
        }
    }
}
